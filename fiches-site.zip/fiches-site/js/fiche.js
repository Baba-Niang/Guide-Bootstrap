/* Coloration VS Code Dark+ des blocs .code + envoi de la hauteur au site (index.html) */
(function(){
var E=function(s){return s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")};
var S=function(c,s){return '<span class="'+c+'">'+E(s)+'</span>'};
function val(v){return v.replace(/('[^']*')|(#[0-9a-fA-F]{3,8}\b|-?\d*\.?\d+[a-z%]*)|([a-zA-Z-]+)|([^'#\w-]+)/g,function(m,a,b,c,d){return a?S('tk-s',a):b?S('tk-n',b):c?S('tk-k',c):E(d)})}
function css(t){return t.replace(/(\/\*[\s\S]*?\*\/)|([^{}:;]+)(?=\s*\{)|([a-z-]+)(\s*:\s*)([^;}]+)(;?)|([{}])/gi,function(m,cm,sel,p,col,v,sc,br){
if(cm)return S('tk-c',cm);
if(sel){var l=sel.match(/^\s*/)[0];return l+S('tk-sel',sel.slice(l.length))}
if(p)return S('tk-p',p)+E(col)+val(v)+E(sc);
return E(br)})}
function html(t){return t.replace(/(<\/?)([\w-]+)((?:\s+[\w-]+(?:="[^"]*")?)*)(\s*>)/g,function(m,o,n,a,c){
return S('tk-b',o)+S('tk-t',n)+a.replace(/([\w-]+)(="[^"]*")?/g,function(x,k,v){return S('tk-a',k)+(v?S('tk-b','=')+S('tk-s',v.slice(1)):'')})+S('tk-b',c)})}
try{document.querySelectorAll('.code').forEach(function(el){var t=el.textContent;el.innerHTML=/^\s*</.test(t)?html(t):css(t)})}catch(e){}
/* Hauteur auto de l'iframe quand la fiche est affichée dans le site */
if(window.parent!==window){
  var send=function(){parent.postMessage({fiche:location.pathname.split('/').pop(),h:document.documentElement.scrollHeight},'*')};
  addEventListener('load',send);
  if(window.ResizeObserver)new ResizeObserver(send).observe(document.body);
}
})();
