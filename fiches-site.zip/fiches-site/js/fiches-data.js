/* Liste des fiches du site, dans l'ordre d'affichage.
   L'agent AJOUTE une ligne par fiche terminée. */
window.FICHES=[
  {id:"9B", titre:"Tableaux avec CSS (partie 1)", fichier:"fiches/fiche-9B-tableaux-css.html"},
  {id:"14", titre:"Flexbox (les bases)", fichier:"fiches/fiche-14-flexbox.html"}
];
