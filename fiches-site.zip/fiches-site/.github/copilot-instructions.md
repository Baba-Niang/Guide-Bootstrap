Lis et applique intégralement le fichier `AGENTS.md` à la racine du dépôt.
Règle essentielle : une seule fiche par tâche, contenu 100 % fidèle à l'image (rien résumé ni supprimé),
mise en page selon `css/style.css`, `fiches/_modele.html` et les exemples de `references/`.
