# Mission : transformer des fiches (images) en pages HTML, puis en site

Ce dépôt contient des fiches pédagogiques HTML/CSS. Tu transformes des images de
fiches (dossier `sources/`) en pages HTML fidèles, qui s'affichent ensuite dans
un site où l'on défile fiche par fiche (`index.html`).

## Règle n°1 : UNE SEULE FICHE PAR TÂCHE
Traite la fiche demandée, termine-la, valide-la, puis ARRÊTE-TOI.
Ne génère jamais plusieurs fiches dans la même réponse : la qualité baisse
(contenu résumé, style qui dérive). Si on te donne plusieurs fiches, fais-les
l'une après l'autre, chacune avec son propre commit.

## Ressources du dépôt
- `css/style.css` : charte commune (couleurs, cartes, code, mode sombre). Ne pas la dupliquer.
- `js/fiche.js` : coloration du code (VS Code Dark+) + hauteur auto dans le site. À inclure dans chaque fiche.
- `fiches/_modele.html` : squelette à copier pour chaque nouvelle fiche.
- `references/` : 2 fiches validées par l'utilisateur. Leur niveau de qualité et de mise en page est LA référence. Lis-les avant de commencer.
- `sources/fiche-XX.png` : l'image de la fiche à coder.
- `inventaires/` : l'inventaire du contenu de chaque fiche.
- `js/fiches-data.js` : la liste des fiches du site.

## Procédure pour chaque fiche (dans cet ordre)
1. **Inventaire.** Ouvre l'image. Transcris TOUT son contenu dans `inventaires/fiche-XX.md` :
   titre, sous-titre, auteur, balises, définition, chaque section, chaque bloc (titre, texte,
   code exact, avant/après, astuce), exemple complet, « à retenir », bandeau final.
   Une ligne par élément. Si un mot est illisible, écris `[?]` et signale-le.
2. **Codage.** Copie `fiches/_modele.html` vers `fiches/fiche-XX-slug.html`
   (ex. `fiche-14-flexbox.html`). Utilise `css/style.css` ; le CSS spécifique à la fiche
   (démos) va dans le `<style>` de la fiche.
3. **Vérification.** Reprends l'inventaire ligne par ligne et coche chaque élément retrouvé
   dans le HTML. Il ne doit manquer aucun mot. Vérifie aussi que le code affiché est identique
   à l'image et que les démos fonctionnent.
4. **Enregistrement.** Ajoute la fiche dans `js/fiches-data.js` (id, titre, fichier).
   Ouvre `index.html` : la fiche doit apparaître et s'afficher en entier.
5. **Commit** : `Fiche XX : <titre>`. Puis arrête-toi.

## Fidélité du contenu (priorité absolue)
- Ne supprime, ne résume, ne reformule RIEN. Mêmes titres, mêmes textes, même code,
  mêmes astuces, même ordre logique. La mise en page peut changer, jamais le contenu.
- Corrige seulement les fautes de frappe évidentes, et liste-les dans ton compte rendu.
- Les petits textes de l'image comptent autant que les gros.

## Règles de mise en page
- Format paysage, grande écriture : texte courant 19 px minimum, code 16 px minimum.
- Blocs ajustés à leur contenu : aucune carte avec une marge vide. Choisis la grille
  (`r2`, `r3`, `r4`, `r2-1`, `r1-2`) pour que chaque ligne soit pleine ; fais s'étirer
  démos et listes (`grow`, `flex:1`) plutôt que de laisser du blanc.
- Schémas, avant/après, tableaux, démos : toujours du vrai HTML/CSS, jamais une image
  de l'original. Les démos doivent produire réellement le résultat décrit
  (ex. un vrai `display:flex`).
- Blocs de code : `<pre class="code">`, échapper `&lt;` `&gt;` dans le HTML. La coloration
  est automatique.
- Couleurs : utilise les variables de `style.css`, pas de couleurs en dur
  (sauf couleurs qui font partie de l'exemple enseigné, ex. `#2563eb`).
- Mode sombre automatique et affichage correct sur mobile.
- Pas de bibliothèque externe, pas de localStorage. Seule la police Google Fonts est autorisée.

## Test avant de dire « terminé »
- La fiche s'ouvre seule (`fiches/fiche-XX.html`) ET dans `index.html`.
- Aucun texte coupé, aucun débordement horizontal, à 1440 px et à 390 px de large.
- Inventaire entièrement coché.

## Compte rendu final (court)
Fiche créée, fautes corrigées, éléments douteux à vérifier par l'utilisateur.
