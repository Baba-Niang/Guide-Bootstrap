# Fiches HTML & CSS

Site de fiches pédagogiques à défilement vertical, une fiche par section.

## Structure
- `index.html` : le site (menu + défilement fiche par fiche)
- `fiches/` : une page HTML par fiche (+ `_modele.html`)
- `css/style.css`, `js/fiche.js` : charte et script communs
- `js/fiches-data.js` : liste des fiches affichées
- `sources/` : images des fiches à coder · `inventaires/` : transcription du contenu
- `references/` : fiches validées servant d'exemples
- `AGENTS.md` : instructions pour les agents (Copilot, z.ai, Claude Code…)

## Utilisation avec un agent
1. Déposer `sources/fiche-XX.png`.
2. Prompt : « Code la fiche XX en suivant AGENTS.md. »  (UNE fiche par demande.)
3. Relire, puis passer à la suivante.

## Voir le site
Publier le dépôt avec GitHub Pages (Settings → Pages → branche main, dossier racine),
ou en local : `python3 -m http.server` puis http://localhost:8000
